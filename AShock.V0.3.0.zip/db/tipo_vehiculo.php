<?php
require("conectar.php");

$c = array();
$tipo_vehiculo = $db_con->query("SELECT * FROM tipos ORDER by tipo_car");
	while($datos = $tipo_vehiculo->fetch(PDO::FETCH_ASSOC)) {
		$id = $datos["id_tipo_car"];
		$tipo = $datos['tipo_car'];
    	$c[$id] = $tipo;
	}
print_r(json_encode($c));
 
?>