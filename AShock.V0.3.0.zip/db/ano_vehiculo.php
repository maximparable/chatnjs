<?php
require("conectar.php");

$c = array();
$tipo_vehiculo = $db_con->query("SELECT * FROM anos");
	while($datos = $tipo_vehiculo->fetch(PDO::FETCH_ASSOC)) {
		$id = $datos["id_ano"];
		$tipo = $datos['ano'];
    	$c[$id] = $tipo;
	}
print_r(json_encode($c));
 
?>