<?php
@session_start();
	require("conectar.php");
?>