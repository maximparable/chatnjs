<?php
require("conectar.php");
$c = array();
$fabricante_vehiculo = $db_con->query("SELECT * FROM fabricantes");
	while($datos = $fabricante_vehiculo->fetch(PDO::FETCH_ASSOC)) {
		$id = $datos["id_fabricante"];
		$fabricante = $datos['fabricante'];
    	$c[$id] = $fabricante;
	}
print_r(json_encode($c));
 

?>