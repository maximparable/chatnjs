		<script src="ext/js/jquery-3.1.1.min.js"></script>
		<script src="ext/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="ext/js/main.js"></script>
		<script type="text/javascript" src="ext/js/imagenes.js"></script>
		<script type="text/javascript" src="ext/js/chat.js"></script>
		<script type="text/javascript" src="ext/js/registrar.js"></script>
		<script type="text/javascript" src="ext/js/login.js"></script>
		
		<!--<script type="text/javascript" src="ext/js/security.js"></script> <script type="text/javascript" src="https://cdn.ywxi.net/js/1.js" async></script>-->
		