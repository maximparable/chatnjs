$(document).ready(function() {
// JavaScript Document
	'use strict';
///////////////////////////////////////////////////////////////////////////////////////
	function imagen1(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto1").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}$("#foto1").attr("width", "200");
	}$('#imagen1').change(imagen1);
///////////////////////////////////////////////////////////////////////////////////////
	function imagen2(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto2").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}$("#foto2").attr("width", "200");
	}$('#imagen2').change(imagen2);
///////////////////////////////////////////////////////////////////////////////////////
	function imagen3(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto3").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}$("#foto3").attr("width", "200");
	}$('#imagen3').change(imagen3);
///////////////////////////////////////////////////////////////////////////////////////
	function imagen4(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto4").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}$("#foto4").attr("width", "200");
	}$('#imagen4').change(imagen4);
///////////////////////////////////////////////////////////////////////////////////////
	function imagen5(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto5").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}$("#foto5").attr("width", "200");
	}$('#imagen5').change(imagen5);
///////////////////////////////////////////////////////////////////////////////////////////////
	function imagen6(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto_taller").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}
	}$('#imagen_taller').change(imagen6);
///////////////////////////////////////////////////////////////////////////////////////////////
	function imagen7(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto_perfil").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}
	}$('#perfil_grua').change(imagen7);
///////////////////////////////////////////////////////////////////////////////////////
	function imagen8(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto_grua").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}
	}$('#imagen_grua').change(imagen8);
///////////////////////////////////////////////////////////////////////////////////////
	function imagen9(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto9").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}$("#foto9").attr("width", "200");
	}$('#imagen9').change(imagen9);
///////////////////////////////////////////////////////////////////////////////////////
	function imagen10(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto10").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}$("#foto10").attr("width", "200");
	}$('#imagen10').change(imagen10);
///////////////////////////////////////////////////////////////////////////////////////
	function imagen11(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto11").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}$("#foto11").attr("width", "200");
	}$('#imagen11').change(imagen11);
///////////////////////////////////////////////////////////////////////////////////////
	function imagen12(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					$("#foto12").attr("src", e.target.result).join('');
				};
			})(f);
			reader.readAsDataURL(f);
		}$("#foto12").attr("width", "200");
	}$('#imagen12').change(imagen12);
///////////////////////////////////////////////////////////////////////////////////////
});