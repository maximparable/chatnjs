<!DOCTYPE html>
<html>
	<head>

		<title>Ashock</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="description" content="By MCDeveloper." />
		<meta name="keywords"  content="key1,key1,key1" />
		<meta name="Resource-type" content="Document" />
		<meta name="author" content="mcdeveloper" />

		<?php
		require("db/conectar.php");
		require("db/consulta_usuario.php");
		require("ext/styles.php");
		require("ext/scripts.php");
		?>
		
	</head>
	<body>
		<div id="wrapper">
			<div class="overlay"></div>
			<!-- Sidebar -->
			<nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">				
				<ul class="nav sidebar-nav">
					<li class="sidebar-brand" style="background: #000 url(<?php if($login==1) { echo $foto_frontal; } ?>) no-repeat; background-size: cover;">
						<img src="<?php if($login==1){echo $foto_perfil;} ?>" class="img-circle" width="67" alt="">
						<p><?php if($login==1){echo $correo;} ?></p>
					</li>
					<li>
						<a id="micuenta" href="#Micuenta">Mi cuenta</a>
					</li>
					<li>
						<a id="historia" href="#">Historial</a>
					</li>
					<li>
						<a class="ayuda" href="#">Ayuda</a>
					</li>
					<li>
						<a class="cerrar" href="#">Cerrar sesión</a>
					</li>
					<hr width="100%"><br>
					<center style="clear:both;">
						<img src="img/logo.png" width="45%" alt="">
					</center>
					<h4 align="center">Assistance Shock</h4>
				</ul>
			</nav>
			<!-- /#sidebar-wrapper -->
			<!-- Page Content -->
			<div id="page-content-wrapper">
				
				<div id="portal">
					
					<div id="register-login">
					<?php require("./estruc/register-login.php"); ?>
					</div>
					<div id="register-clients" class="hidden">
					<?php require("./estruc/register-clients.php"); ?>
					</div>
					<form id="registrer-usuario" enctype="multipart/form-data">
					<?php require("./estruc/register-users.php"); ?>
					</form>
					<form id="register-taller" method="post" enctype="multipart/form-data">
					<?php require("./estruc/register-taller.php"); ?>
					</form>
					<form id="regis-grua" method="post" enctype="multipart/form-data">
					<?php require("./estruc/register-grua.php"); ?>
					</form>
					<div id="login" class="hidden">
					<?php require("./estruc/login.php"); ?>
					</div>
					<div id="cuenta" class="hidden">
					</div>
					
				</div>
				
				<div id="home" class="hidden">
					<header>
						<div class="header-top clearfix">
							<a class="l-left toggle-menu" href="#">
								<button type="button" class="hamburger is-closed" data-toggle="offcanvas">
									<span class="hamb-top"></span>
									<span class="hamb-middle"></span>
									<span class="hamb-bottom"></span>
								</button>
							</a>
							<a class="l-right toggle-massage" href="#">
							  <i id="btn-chat" class="fa fa-comment"></i>
							</a>
						</div>
					</header>
					<div id="fullpage">
						<div id="map"></div>
					</div>
					<footer class="desktop">
						<h6 align="center">
							<img id="taller" class="l-left" src="img/icon1.png" alt="img1">
							<img id="asistente" src="img/icon2.png" alt="img2">
							<img id="grua" class="l-right" src="img/icon3.png" style="margin: 0;" alt="img3">
						</h6>
					</footer>
				</div>
				
				<div id="chat" class="hidden">
					<?php require("./estruc/chat.php"); ?>
				</div>
				
			</div>
			<!-- /#page-content-wrapper -->
			
		</div>
	
    <script type="text/javascript" src="https://ashock.app:3000/socket.io/socket.io.js"></script>
	</body>
</html>
