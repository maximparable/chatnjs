						<div class="container">
							<center><img src="img/logo.png" width="45%" alt=""></center>
							<br><h1 align="center">Assistane Shock</h1><br>
							<button id="registro" type="button" class="btn btn-big btn-warning">Registro</button>
							<button id="ingreso" type="button" class="btn btn-big btn-warning">Ingresar</button>
							<br><br>
							<h2>¡Bienvenido!</h2>
						</div>
						<footer style="background: transparent">
							<span id="ayuda" style="color: #2095F2" class="l-right"> Ayuda </span>
							<i class="fa fa-info-circle l-right" style="color: #2095F2"></i>
						</footer>