					<div id="taller1" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Taller 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente1"></i>
								</h2>
							</div>
						</header>
						<div class="container"><br><br>
							<div class="form-group">
								<label class="control-label">Fotografia taller*</label>
								<label for="imagen_taller" style="cursor: pointer; width: 100% !important;">
									<img id="foto_taller" src="img/vehiculos/foto.png" width="100%" alt="">
								</label>
								<input id="imagen_taller" type="file" name="imagen_taller" style="display: none; cursor: pointer !important;">
								<input type="number" class="form-control" name="id_perfil" value="4" style="display: none">
							</div>
							<div class="form-group">
								<label class="control-label" for="nit">Nit*</label>
								<input type="number" class="form-control" placeholder="00000000" name="nit" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="nombres">Empresa*</label>
								<input type="text" class="form-control" placeholder="Taller_Empresa" name="empresa" id="empresa" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="direccion">Dirección*</label>
								<input type="text" class="form-control" placeholder="Cra 0 #00-00" name="dir_empresa" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="correo">Correo(Usuario)*</label>
								<input type="text" class="form-control" name="correo_empresa" autocomplete="off" value="" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="contrasena">Contraseña*</label>
								<input type="password" class="form-control" name="contra_empresa" autocomplete="off" required>
							</div>
							<button id="siguiente_taller1" class="btn btn-warning btn-big siguiente1" type="button">Siguiente</button>
						</div><br><br>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar1" class="l-left regresar1" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="taller2" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Taller 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente2"></i>
								</h2>
							</div>
						</header>
						<div class="container"><br><br>
							<div class="form-group">
								<label class="control-label" for="telefono">Numero de contacto*</label>
								<input type="number" class="form-control" name="telefono_empresa" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="dias">Días de atención*</label>
								<input type="text" class="form-control" placeholder="lunes, martes, miercoles, jueves, viernes" name="dias_atencion" id="dias" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="dias">Días de atención*</label>
							</div>
							<div class="form-group col-sm-12 col-md-6 col-lg-6">
								<label class="control-label" for="hora_inicio">Desde </label> 
								<input type="number" placeholder="Hora" name="hora_inicio" class="time"> <b>:</b>
								<input type="number" placeholder="Minuto" name="minuto_inicio" class="time"> <b>:</b>
								<input type="number" placeholder="Segundo" name="segundo_inicio" class="time">
							</div>
							<div class="form-group col-sm-12 col-md-6 col-lg-6">
								<label class="control-label" for="horas_atencion">Hasta </label> 
								<input type="number" placeholder="Hora" name="hora_fin" class="time"> <b>:</b>
								<input type="number" placeholder="Minuto" name="minuto_fin" class="time"> <b>:</b>
								<input type="number" placeholder="Segundo" name="segundo_fin" class="time">
							</div>
							<button id="siguiente_taller2" class="btn btn-warning btn-big siguiente2" type="button">Siguiente</button>
						</div><br><br>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar_taller2" class="l-left regresar2" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="taller3" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px" class="fa fa-check l-right guardar_taller"></i>
								</h2>
							</div>
						</header>
						<div class="container">
							<center><img src="img/logo.png" width="45%" alt=""></center>
							<br><h1 align="center">Assistane Shock</h1><br>
							<p align="center">
								<input type="checkbox" id="t2" class="c2" required>
								<label for="t2">
									<span></span> Acepto las 
									<a href="ext/docs/politicas.pdf" target="_blank">
										Política de privacidad, Términos y condiciones
									</a>
								</label>
							</p>
							<div id="error_taller" class="error"></div>
							<button id="guardar_taller" class="btn btn-warning btn-big guardar_taller" type="button">Aceptar</button><br><br>
						</div><br><br>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar_taller3" class="l-left regresar3" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>