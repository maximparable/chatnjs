//$(document).ready(function(){
//	"use strict";
//io('http://dominio.com');
//io();
const socket = io();

let mychat = document.getElementById('mychat');
let message = document.getElementById('message');
let ejecuta = document.getElementById('actions');
let output = document.getElementById('output');
var username = document.getElementById('username');
let enviar = document.getElementById('send');
/*
$("mychat").submit(function(){
	console.log('click');
	
});*/	 
enviar.addEventListener('click', function(){
	socket.emit('chatsend:message', {
		username: username.value,
		message: message.value
	});
	$("#message").val("");
});
enviar.addEventListener('keypress', function(){
	socket.emit('chat:writing', username);
});
socket.on('chatget:message', function (data) {
	if(username.value == data.username){
		$(".panel-body form").append(
			'<div class="form-group">'+data.username+
				'<br><span class="fa fa-lg fa-user pb-chat-fa-user"></span>'+
				'<span class="label label-default pb-chat-labels pb-chat-labels-left">'+data.message+'</span>'+		
			'</div>'+
			'<hr>'
		);
	}else{
		$(".panel-body form").append(
			'<div class="form-group pull-right pb-chat-labels-right">'+data.username+
				'<br><span class="label label-primary pb-chat-labels pb-chat-labels-primary">'+data.message+'</span><span class="fa fa-lg fa-user pb-chat-fa-user"></span>'+		
			'</div><div class="clearfix"></div>'+
			'<hr>'
		);
	}
	
	
	//console.log(data);
		
});
	//$("#send").click(function(){	});
	//$("#send").click(function(){	});
	/**/
//});